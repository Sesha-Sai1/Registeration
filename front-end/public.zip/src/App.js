import logo from "./logo.svg";
import "./App.css";
import Registeration from "./components/Registeration";

function App() {
  return (
    <div className="App">
      <Registeration />
    </div>
  );
}

export default App;
